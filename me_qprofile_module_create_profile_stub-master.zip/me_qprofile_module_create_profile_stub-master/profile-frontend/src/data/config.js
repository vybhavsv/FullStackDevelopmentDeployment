
module.exports = {
  // TODO: change your profile information here
  name: "Ashok Kumar",
  greeting: "Hey 👋",
  greetingDescription: "I'm Ashok Kumar and I'm a Software Engineer!",
  githubUrl: "https://github.com/ashokkumar95",
  linkedinUrl: "https://linkedin.com/ashokkumar1",
  cvLink: "https://docs.google.com/document/d/1E1234561NMyQA67890ygda7abcdefghijs1jBp7HFI0/",
};
